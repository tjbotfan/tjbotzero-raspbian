ggrep -v -E "うみなし"
