#cp -v -r node-red/packages/node_modules/\@node-red/editor-client/locales/ja* node_modules/\@node-red/editor-client/locales/
#cp -v -r node-red/packages/node_modules/\@node-red/nodes/locales/ja* node_modules/\@node-red/nodes/locales/


mkdir -p \@node-red/editor-client/locales/
cp -v -r node-red/packages/node_modules/\@node-red/editor-client/locales/ja* \@node-red/editor-client/locales/
mkdir -p \@node-red/nodes/locales/
cp -v -r node-red/packages/node_modules/\@node-red/nodes/locales/ja* \@node-red/nodes/locales/
mkdir -p \@node-red/editor-client/locales/ja
cp -v editor.json \@node-red/editor-client/locales/ja/editor.json
