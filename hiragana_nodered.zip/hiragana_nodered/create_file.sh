cat $2 | sh manual_replacement.sh $1 > tmp.txt

cat tmp.txt | sh create_replaceshell.sh $1 > tmp.sh
cat tmp.txt | sh tmp.sh > $3

#head -n 250 tmp.txt | sh create_replaceshell.sh $1 > tmp.sh
#cat tmp.txt | sh tmp.sh > tmp2.txt
#mv tmp2.txt tmp.txt

#head -n 500 tmp.txt | tail -n 250 | sh create_replaceshell.sh $1 > tmp.sh
#cat tmp.txt | sh tmp.sh > tmp2.txt
#mv tmp2.txt tmp.txt

#head -n 750 tmp.txt | tail -n 250 | sh create_replaceshell.sh $1 > tmp.sh
#cat tmp.txt | sh tmp.sh > tmp2.txt
#mv tmp2.txt tmp.txt

#head -n 1000 tmp.txt | tail -n 250 | sh create_replaceshell.sh $1 > tmp.sh
#cat tmp.txt | sh tmp.sh > tmp2.txt
#mv tmp2.txt tmp.txt

#cp tmp.txt $3

#tail -n 500 tmp2.txt | sh create_replaceshell.sh $1 > tmp.sh
#cat tmp2.txt | sh tmp.sh > $3

#rm tmp2.txt
rm tmp.txt tmp.sh
