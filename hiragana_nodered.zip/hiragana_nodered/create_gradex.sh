mkdir -p node-red/packages/node_modules/\@node-red/editor-client/locales/ja-grade$1
sh create_file.sh $1 node-red/packages/node_modules/\@node-red/editor-client/locales/ja/editor.json node-red/packages/node_modules/\@node-red/editor-client/locales/ja-grade$1/editor.json 
sh create_file.sh $1 node-red/packages/node_modules/\@node-red/editor-client/locales/ja/infotips.json node-red/packages/node_modules/\@node-red/editor-client/locales/ja-grade$1/infotips.json
sh create_file.sh $1 node-red/packages/node_modules/\@node-red/editor-client/locales/ja/jsonata.json node-red/packages/node_modules/\@node-red/editor-client/locales/ja-grade$1/jsonata.json

mkdir -p node-red/packages/node_modules/\@node-red/nodes/locales/ja-grade$1
# sh create_file.sh $1 node-red/packages/node_modules/\@node-red/nodes/locales/ja/messages.json node-red/packages/node_modules/\@node-red/nodes/locales/ja-grade$1/messages.json 

#cat node-red/packages/node_modules/\@node-red/nodes/locales/ja/messages.json | awk '1<=NR && NR<=250' > messages.json.0
#cat node-red/packages/node_modules/\@node-red/nodes/locales/ja/messages.json | awk '251<=NR && NR<=500' > messages.json.1
#cat node-red/packages/node_modules/\@node-red/nodes/locales/ja/messages.json | awk '501<=NR && NR<=750' > messages.json.2
#cat node-red/packages/node_modules/\@node-red/nodes/locales/ja/messages.json | awk '751<=NR && NR<=1000' > messages.json.3
#sh create_file.sh $1 messages.json.0 messages.json.0.tmp
#sh create_file.sh $1 messages.json.1 messages.json.1.tmp
#sh create_file.sh $1 messages.json.2 messages.json.2.tmp
#sh create_file.sh $1 messages.json.3 messages.json.3.tmp
#cat messages.json.0.tmp messages.json.1.tmp messages.json.2.tmp messages.json.3.tmp > node-red/packages/node_modules/\@node-red/nodes/locales/ja-grade$1/messages.json 
#rm messages.json.0 messages.json.1 messages.json.2 messages.json.3 messages.json.0.tmp messages.json.1.tmp messages.json.2.tmp messages.json.3.tmp
cat node-red/packages/node_modules/\@node-red/nodes/locales/ja/messages.json | gsed -r "s/&/＆/g" > messages.json
sh create_file.sh $1 messages.json messages.json.tmp
cat messages.json.tmp | gsed -r "s/＆/&/g" > node-red/packages/node_modules/\@node-red/nodes/locales/ja-grade$1/messages.json 
rm messages.json messages.json.tmp

mkdir -p node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/parsers
mkdir -p node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/network
mkdir -p node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/function
mkdir -p node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/storage
mkdir -p node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/common
mkdir -p node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/sequence

sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/parsers/70-YAML.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/parsers/70-YAML.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/parsers/70-JSON.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/parsers/70-JSON.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/parsers/70-HTML.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/parsers/70-HTML.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/parsers/70-CSV.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/parsers/70-CSV.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/parsers/70-XML.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/parsers/70-XML.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/network/21-httpin.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/network/21-httpin.html

#sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/network/21-httprequest.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/network/21-httprequest.html
cat node-red/packages/node_modules/@node-red/nodes/locales/ja/network/21-httprequest.html | gsed -r "s/、\/、/、／、/" | gsed -r "s/、&/、＆/" > 21-httprequest.html
sh create_file.sh $1 21-httprequest.html 21-httprequest.html.tmp
cat 21-httprequest.html.tmp | gsed -r "s/、／、/、\/、/"  | gsed -r "s/、＆/、&/" > node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/network/21-httprequest.html
rm 21-httprequest.html 21-httprequest.html.tmp

sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/network/32-udp.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/network/32-udp.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/network/05-tls.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/network/05-tls.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/network/10-mqtt.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/network/10-mqtt.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/network/22-websocket.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/network/22-websocket.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/network/06-httpproxy.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/network/06-httpproxy.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/network/31-tcpin.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/network/31-tcpin.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/function/15-change.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/function/15-change.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/function/89-delay.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/function/89-delay.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/function/10-function.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/function/10-function.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/function/90-exec.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/function/90-exec.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/function/80-template.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/function/80-template.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/function/16-range.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/function/16-range.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/function/89-trigger.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/function/89-trigger.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/function/10-switch.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/function/10-switch.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/storage/10-file.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/storage/10-file.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/storage/23-watch.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/storage/23-watch.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/common/24-complete.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/common/24-complete.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/common/98-unknown.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/common/98-unknown.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/common/21-debug.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/common/21-debug.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/common/25-catch.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/common/25-catch.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/common/90-comment.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/common/90-comment.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/common/20-inject.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/common/20-inject.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/common/25-status.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/common/25-status.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/common/60-link.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/common/60-link.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/sequence/19-batch.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/sequence/19-batch.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/sequence/18-sort.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/sequence/18-sort.html
sh create_file.sh $1 node-red/packages/node_modules/@node-red/nodes/locales/ja/sequence/17-split.html node-red/packages/node_modules/@node-red/nodes/locales/ja-grade$1/sequence/17-split.html

