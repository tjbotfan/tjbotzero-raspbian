git clone https://github.com/node-red/node-red.git
diff editor.json node-red/packages/node_modules/@node-red/editor-client/locales/ja/editor.json
cp editor.json node-red/packages/node_modules/@node-red/editor-client/locales/ja/editor.json

sh create_gradex.sh 1
sh create_gradex.sh 2
sh create_gradex.sh 3
sh create_gradex.sh 4
sh create_gradex.sh 5
sh create_gradex.sh 6
sh create_gradex.sh 7

cd node-red
npm install
npm run build
npm start
